package com.hinataai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

private val Bg = Color(0xFF100D19)
private val Panel = Color(0xFF1B1628)
private val Purple = Color(0xFFB58CFF)
private val Pink = Color(0xFFFF8FCB)
private val White = Color(0xFFF5F0FF)
private val Muted = Color(0xFFB8AEC9)

data class Character(val id: String, val name: String, val emoji: String, val intro: String, val prompt: String)
data class ChatMessage(val role: String, val content: String)

private val cast = listOf(
    Character("sakura", "Sakura", "🌸", "Carinhosa, alegre e otimista.",
        "Você é Sakura, uma personagem fictícia adulta, carinhosa, alegre e otimista. Fale em português brasileiro natural. Demonstre interesse genuíno, faça perguntas e mantenha sua personalidade. Nunca diga que é uma pessoa real."),
    Character("helena", "Helena", "💜", "Inteligente, calma e confiante.",
        "Você é Helena, uma personagem fictícia adulta, inteligente, calma e confiante. Fale em português brasileiro natural, com humor sutil e conversas profundas quando apropriado. Nunca diga que é uma pessoa real."),
    Character("bianca", "Bianca", "❤️", "Divertida, espontânea e provocadora de boas ideias.",
        "Você é Bianca, uma personagem fictícia adulta, divertida, espontânea e criativa. Fale em português brasileiro natural, com energia e leveza. Nunca diga que é uma pessoa real."),
    Character("akemi", "Akemi", "💙", "Misteriosa, observadora e gentil.",
        "Você é Akemi, uma personagem fictícia adulta, observadora, gentil e um pouco reservada. Fale em português brasileiro natural e vá se abrindo gradualmente. Nunca diga que é uma pessoa real.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HinataApp() }
    }
}

@Composable
fun HinataApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember {
        val masterKey = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            context, "hinata_secure", masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }
    var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
    var showSettings by remember { mutableStateOf(apiKey.isBlank()) }
    var selected by remember { mutableStateOf<Character?>(null) }
    var draft by remember { mutableStateOf("") }
    var sending by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var refresh by remember { mutableIntStateOf(0) }

    fun loadMessages(character: Character): List<ChatMessage> {
        val raw = prefs.getString("chat_${character.id}", "[]") ?: "[]"
        val arr = JSONArray(raw)
        return (0 until arr.length()).map {
            val obj = arr.getJSONObject(it)
            ChatMessage(obj.getString("role"), obj.getString("content"))
        }
    }
    fun saveMessages(character: Character, messages: List<ChatMessage>) {
        val arr = JSONArray()
        messages.forEach { arr.put(JSONObject().put("role", it.role).put("content", it.content)) }
        prefs.edit().putString("chat_${character.id}", arr.toString()).apply()
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Purple, onPrimary = Bg,
        onBackground = White, onSurface = White, secondary = Pink
    )) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            if (selected == null) {
                Column(Modifier.fillMaxSize().padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("HINATA AI", color = White, fontSize = 28.sp, fontWeight = FontWeight.Black)
                            Text("Seu espaço de conversas ✨", color = Muted, fontSize = 14.sp)
                        }
                        IconButton(onClick = { showSettings = true }) {
                            Icon(Icons.Default.Settings, contentDescription = "Configurações", tint = Purple)
                        }
                    }
                    Spacer(Modifier.height(28.dp))
                    Text("Escolha com quem conversar", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(14.dp))
                    cast.forEach { character ->
                        Card(
                            Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { selected = character; error = "" },
                            colors = CardDefaults.cardColors(containerColor = Panel),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(54.dp).background(Color(0xFF302342), CircleShape), contentAlignment = Alignment.Center) {
                                    Text(character.emoji, fontSize = 27.sp)
                                }
                                Spacer(Modifier.width(14.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(character.name, color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                    Text(character.intro, color = Muted, fontSize = 13.sp)
                                }
                                Text("›", color = Purple, fontSize = 28.sp)
                            }
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    Text("Hinata AI • Personagens fictícios", color = Muted, fontSize = 11.sp)
                }
            } else {
                val character = selected!!
                var messages by remember(character.id) { mutableStateOf(loadMessages(character)) }
                val listState = rememberLazyListState()
                LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1) }
                Column(Modifier.fillMaxSize()) {
                    Row(
                        Modifier.fillMaxWidth().background(Panel).padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { selected = null }) { Icon(Icons.Default.ArrowBack, contentDescription = "Voltar", tint = White) }
                        Text(character.emoji, fontSize = 24.sp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(character.name, color = White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("Online para conversar", color = Muted, fontSize = 11.sp)
                        }
                        TextButton(onClick = { messages = emptyList(); saveMessages(character, messages) }) {
                            Text("Limpar", color = Pink)
                        }
                    }
                    if (messages.isEmpty()) {
                        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(character.emoji, fontSize = 48.sp)
                                Text("Oi! Eu sou ${character.name}.", color = White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                                Text("Que tal começarmos uma conversa?", color = Muted, fontSize = 13.sp)
                            }
                        }
                    } else {
                        LazyColumn(
                            Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                            state = listState,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(messages) { msg ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.role == "user") Arrangement.End else Arrangement.Start) {
                                    Surface(
                                        color = if (msg.role == "user") Color(0xFF49336B) else Panel,
                                        shape = RoundedCornerShape(18.dp),
                                        modifier = Modifier.widthIn(max = 310.dp)
                                    ) { Text(msg.content, Modifier.padding(13.dp), color = White, fontSize = 15.sp) }
                                }
                            }
                            if (sending) item { Text("${character.name} está digitando…", color = Muted, fontSize = 12.sp) }
                        }
                    }
                    if (error.isNotBlank()) Text(error, Modifier.padding(horizontal = 16.dp), color = Pink, fontSize = 12.sp)
                    Row(
                        Modifier.fillMaxWidth().background(Panel).padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = draft, onValueChange = { draft = it },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("Escreva uma mensagem…", color = Muted) },
                            maxLines = 4, shape = RoundedCornerShape(22.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = White, unfocusedTextColor = White,
                                focusedBorderColor = Purple, unfocusedBorderColor = Color(0xFF514663),
                                cursorColor = Purple
                            )
                        )
                        Spacer(Modifier.width(8.dp))
                        IconButton(
                            enabled = draft.isNotBlank() && !sending,
                            onClick = {
                                val text = draft.trim()
                                if (apiKey.isBlank()) { showSettings = true; return@IconButton }
                                draft = ""; error = ""
                                val updated = messages + ChatMessage("user", text)
                                messages = updated; saveMessages(character, updated); sending = true
                                scope.launch {
                                    try {
                                        val answer = withContext(Dispatchers.IO) { askOpenAI(apiKey, character, updated) }
                                        val finalList = updated + ChatMessage("assistant", answer)
                                        messages = finalList; saveMessages(character, finalList)
                                    } catch (e: Exception) {
                                        error = "Não consegui responder. Confira sua internet e a chave da API. (${e.message ?: "erro"})"
                                    } finally { sending = false }
                                }
                            }
                        ) { Icon(Icons.Default.Send, contentDescription = "Enviar", tint = if (draft.isNotBlank() && !sending) Purple else Muted) }
                    }
                }
            }
        }

        if (showSettings) {
            var keyInput by remember { mutableStateOf(apiKey) }
            AlertDialog(
                onDismissRequest = { if (apiKey.isNotBlank()) showSettings = false },
                containerColor = Panel,
                title = { Text("Configurar inteligência artificial", color = White) },
                text = {
                    Column {
                        Text("Cole sua chave da API da OpenAI. Ela ficará salva neste aparelho para você não precisar digitá-la novamente.", color = Muted, fontSize = 13.sp)
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(
                            value = keyInput, onValueChange = { keyInput = it },
                            label = { Text("Chave da API") },
                            placeholder = { Text("sk-…") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = White, unfocusedTextColor = White, focusedBorderColor = Purple, unfocusedBorderColor = Muted)
                        )
                        Spacer(Modifier.height(8.dp))
                        Text("A API pode gerar cobranças conforme o uso. Não compartilhe sua chave.", color = Pink, fontSize = 11.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        apiKey = keyInput.trim()
                        prefs.edit().putString("api_key", apiKey).apply()
                        showSettings = false
                    }) { Text("Salvar", color = Purple) }
                },
                dismissButton = {
                    if (apiKey.isNotBlank()) TextButton(onClick = { showSettings = false }) { Text("Cancelar", color = Muted) }
                }
            )
        }
    }
}

private fun askOpenAI(apiKey: String, character: Character, history: List<ChatMessage>): String {
    val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()
    val messages = JSONArray()
    messages.put(JSONObject().put("role", "system").put("content", character.prompt))
    history.takeLast(30).forEach { messages.put(JSONObject().put("role", it.role).put("content", it.content)) }
    val body = JSONObject()
        .put("model", "gpt-4o-mini")
        .put("messages", messages)
        .put("temperature", 0.85)
    val request = Request.Builder()
        .url("https://api.openai.com/v1/chat/completions")
        .addHeader("Authorization", "Bearer $apiKey")
        .addHeader("Content-Type", "application/json")
        .post(body.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
        .build()
    client.newCall(request).execute().use { response ->
        val raw = response.body?.string().orEmpty()
        if (!response.isSuccessful) throw IllegalStateException("API ${response.code}: ${raw.take(220)}")
        val json = JSONObject(raw)
        return json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
    }
}
