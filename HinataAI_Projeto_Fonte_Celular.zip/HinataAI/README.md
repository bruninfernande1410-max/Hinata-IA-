# Hinata AI (versão inicial)

Aplicativo Android nativo em Kotlin + Jetpack Compose.

## O que já está incluído
- Tela inicial com quatro personagens adultos fictícios: Sakura, Helena, Bianca e Akemi.
- Conversa separada por personagem.
- Histórico salvo localmente no aparelho.
- Integração com a API da OpenAI usando o modelo `gpt-4o-mini`.
- Configuração da chave dentro do app, sem editar código.
- Chave armazenada com Android EncryptedSharedPreferences.

## Como gerar o APK
1. Instale o Android Studio em um computador.
2. Abra a pasta `HinataAI` no Android Studio.
3. Aguarde o Gradle sincronizar e instale os componentes do Android SDK solicitados.
4. No menu **Build**, escolha **Build APK(s)**.
5. O APK de depuração ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## Como usar
1. Instale e abra o aplicativo.
2. Na primeira abertura, cole uma chave de API da OpenAI e toque em Salvar.
3. Escolha um personagem e comece a conversar.

## Importante sobre a chave
A chave é guardada localmente com armazenamento criptografado do Android, mas qualquer chave usada diretamente por um app cliente pode ser extraída por alguém com conhecimento técnico e acesso ao aparelho. Para distribuição pública, substitua a chamada direta por um backend próprio que mantenha a chave no servidor. A API da OpenAI é cobrada separadamente conforme o uso; ChatGPT Plus/Free não inclui créditos de API.

## Requisitos
- Android Studio recente
- JDK 17
- Android SDK 35
- Android 8.0 (API 26) ou superior

## Limitações desta primeira versão
Ainda não inclui voz, envio de imagens, criação de personagens pela interface nem sincronização em nuvem. A base está organizada para acrescentar esses recursos nas próximas versões.


## Gerar o APK usando somente o celular Android (sem PC)

O projeto inclui GitHub Actions para compilar o APK na nuvem.

1. No navegador do celular, entre em https://github.com e crie uma conta ou faça login.
2. Crie um repositório novo chamado `HinataAI`.
3. Extraia o ZIP do projeto no celular usando o gerenciador de arquivos.
4. No repositório, use **Add file > Upload files** e envie os arquivos e pastas extraídos. Inclua também a pasta `.github/workflows`.
5. Aguarde o envio e abra a aba **Actions** do repositório.
6. Abra **Build Hinata AI APK**. Se necessário, toque em **Run workflow**.
7. Quando terminar com sucesso, abra a execução e baixe o artefato **HinataAI-debug-apk**.
8. Extraia o arquivo baixado e instale `app-debug.apk`. O Android pode pedir autorização para instalar apps dessa origem.

A compilação acontece nos servidores do GitHub. Não é necessário instalar Android Studio no celular. O repositório pode ser privado. Nunca coloque sua chave da API no repositório.
